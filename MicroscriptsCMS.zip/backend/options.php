<?php
$correctUN = "asd";
$correctPW = "asdf";
$allowedFileTypes = "jpg,jpeg,png,gif";
$maxFileSizeInMB = 6;
$savesFileDirName = "storedData.txt";
$fileUploadDir = "../images/";
$uploadedFilesDir = "images/";
$loginFallback = "index.php";